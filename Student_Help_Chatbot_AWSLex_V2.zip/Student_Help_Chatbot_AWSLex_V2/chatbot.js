// ====== AWS Configuration ======

// AWS region where the Lex bot is hosted
AWS.config.region = "us-east-1"; 

// AWS credentials (Access Key & Secret Key)
AWS.config.credentials = new AWS.Credentials({
  accessKeyId: "AKIARPUPO6RI2BKNOFFR",         
  secretAccessKey: "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" 
});

// Create a Lex Runtime V2 object to interact with the Lex chatbot
const lexRuntime = new AWS.LexRuntimeV2();

// Storing the bot's information
const botId = "QZLVWENACS";       
const botAliasId = "FYM7NAESC1"; 
const localeId = "en_US";        
const sessionId = Date.now().toString();

// ====== Chat Functions ======

// Function to add messages to the chat window
function appendMessage(message, sender) {
  const chatBox = document.getElementById('chat-box'); // Chat display area
  const div = document.createElement('div');           // Create a new message element
  
  // Apply CSS class based on who sent the message
  div.className = sender === 'user' ? 'user-message' : 'bot-message';
  
  div.textContent = message; // Set the message text
  chatBox.appendChild(div);  // Add it to the chat window

  // Automatically scroll to the latest message smoothly
  chatBox.scrollTo({
    top: chatBox.scrollHeight,
    behavior: 'smooth'
  });
}

// Function to send a user’s typed message to Lex
function sendMessage() {
  const input = document.getElementById('user-input'); // Input text field
  const message = input.value.trim(); // Remove extra spaces

  if (!message) return; // Do nothing if the input is empty

  appendMessage(message, 'user'); // Show user's message in chat
  input.value = ""; // Clear the input box

  // Prepare parameters for AWS Lex API call
  const params = {
    botAliasId: botAliasId,
    botId: botId,
    localeId: localeId,
    sessionId: sessionId,
    text: message
  };

  // Send the message to AWS Lex and handle the bot's response
  lexRuntime.recognizeText(params, (err, data) => {
    if (err) {
      console.error(err);
      appendMessage("Error: Unable to connect to the bot.", 'bot'); // Error message
    } else {
      const messages = data.messages || []; // Get bot's reply
      if (messages.length > 0) {
        appendMessage(messages[0].content, 'bot'); // Display bot's response
      } else {
        appendMessage("Sorry, I didn’t understand that.", 'bot'); // Default fallback
      }
    }
  });
}

// Function to clear the chat history
function clearChat() {
  document.getElementById('chat-box').innerHTML = '';
}

// Function to send predefined (quick button) messages
function sendPredefined(message) {
  document.getElementById('user-input').value = message; // Fill the input box
  sendMessage(); // Send it like a normal message
}

// Allow pressing "Enter" to send messages
document.getElementById('user-input').addEventListener("keypress", function (event) {
  if (event.key === "Enter") {
    sendMessage();
  }
});
